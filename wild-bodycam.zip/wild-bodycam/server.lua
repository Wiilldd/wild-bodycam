--VRP SERVER--

local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP","wild:checkok")


RegisterNetEvent("bodycam:show")
AddEventHandler("bodycam:show", function()
	local user_id = vRP.getUserId({source})

	if vRP.hasGroup({user_id, "Politi-Job"}) then
        TriggerClientEvent("bodycam:show", source, "SAN ANDERES", "HIGHWAY")
    else
        TriggerClientEvent('mythic_notify:client:SendAlert', source, { type = 'error', text = 'Du ikke en del af SAHP'}, 5000)
	end
end)

RegisterNetEvent("bodycam:close")
AddEventHandler("bodycam:close", function()
	local user_id = vRP.getUserId({source})

	if vRP.hasGroup({user_id, "Politi-Job"}) then
        TriggerClientEvent("bodycam:close", source)
    else
		TriggerClientEvent('mythic_notify:client:SendAlert', source, { type = 'error', text = 'Du ikke en del af SAHP'}, 5000)
	end
end)
