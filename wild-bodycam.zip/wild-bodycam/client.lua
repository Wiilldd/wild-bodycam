local PlayerData = {}


Citizen.CreateThread(function()
    while true do 
      Citizen.Wait(0) 
      if GetDistanceBetweenCoords(-1079.8601074219,-823.76092529297,14.882983207703, GetEntityCoords(GetPlayerPed(-1))) < 1.0 then
        DrawMarker(25, -1079.8601074219,-823.76092529297,14.882983207703 - 1, 0, 0, 0, 0, 0, 0, 0.800, 0.800, 0.800, 255, 255, 0, 255, 0, 1, 0, 50)
           DrawText3Ds( -1079.8601074219,-823.76092529297,14.882983207703, "~y~E~s~ | Tag Bodycam")
           if IsControlJustPressed(1, 38) then
            TriggerServerEvent("bodycam:show")
           end
        end
    end
end)


Citizen.CreateThread(function()
    while true do 
      Citizen.Wait(0) 
      if GetDistanceBetweenCoords(-1080.6870117188,-822.78472900391,14.882968902588, GetEntityCoords(GetPlayerPed(-1))) < 1.0 then
        DrawMarker(25, -1080.6870117188,-822.78472900391,14.882968902588 - 1, 0, 0, 0, 0, 0, 0, 0.800, 0.800, 0.800, 255, 255, 0, 255, 0, 1, 0, 50)
           DrawText3Ds( -1080.6870117188,-822.78472900391,14.882968902588, "~y~E~s~ | Læg Bodycam")
           if IsControlJustPressed(1, 38) then
            TriggerServerEvent("bodycam:close")
           end
        end
    end
end)


RegisterNetEvent("bodycam:show")
AddEventHandler("bodycam:show", function(daner, job)
    local year , month, day , hour , minute , second  = GetLocalTime()


    if string.len(tostring(minute)) < 2 then
        minute = '0' .. minute
    end
    if string.len(tostring(second)) < 2 then
        second = '0' .. second
    end
    SendNUIMessage({
        date = day .. '/'.. month .. '/' .. year .. ' ' .. hour .. ':' .. minute .. ':' .. second,
        daneosoby = daner,
        ranga = job,
        open = true,
    })
end)

RegisterNetEvent("bodycam:close")
AddEventHandler("bodycam:close", function()
    SendNUIMessage({
        open = false
    })
end)


--Text Settings--

function DrawText3Ds(x,y,z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    SetTextScale(0.32, 0.32)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 255)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
    local factor = (string.len(text)) / 370
    DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 0, 0, 0, 80)
end
